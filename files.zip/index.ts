// in DisplayDossierViewComponent class

public async onActionClick(action: ActionMeta) {
  if (action.disabledIf) {
    // re-evaluate disabled if you want; we use precomputed flag in arrays above
  }
  const methodName = ACTION_TO_METHOD[action.actionKey];
  if (!methodName) {
    console.warn('No mapping for actionKey', action.actionKey);
    return;
  }
  const method = (this as any)[methodName];
  if (typeof method !== 'function') {
    console.warn('Mapped method not found on component:', methodName);
    return;
  }

  // Pass dossier or specific prop
  const dossier = this.dossierStore.get();
  const arg = action.passDossierProp ? dossier?.[action.passDossierProp] : dossier;

  try {
    // call existing method: many methods expect no param or dossier param or taskStatus param
    const res = method.call(this, arg);
    // if method returns observable/promise, you may await it
    if (res && typeof res.then === 'function') await res;
  } catch (err) {
    console.error('action invocation failed', err);
  }
}
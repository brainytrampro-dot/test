// actions.constants.ts
// - ActionId enum
// - ActionMeta type
// - ACTIONS: full list of actions (id, actionKey, labelKey, icon/class, permissions, visibilityKey/disabledKey placeholders, group left/right)
// NOTE: visibilityIf/disabledIf fields reference rule keys (strings) handled by actions.rules.ts

import { Status } from '@loan-dossier/constants';
import { Permissions, Role } from '@core/constants';

export enum ActionId {
  openDossierRequestsModal = 'openDossierRequestsModal',
  editDossier = 'editDossier',
  responseMoreInfo_initiator = 'responseMoreInfo_initiator',
  responseMoreInfo_decision = 'responseMoreInfo_decision',
  sendToDecisionAuthority = 'sendToDecisionAuthority',
  requestMoreInfo_validator = 'requestMoreInfo_validator',
  requestMoreInfo_combined = 'requestMoreInfo_combined',
  sendBackToDecision = 'sendBackToDecision',
  editRequest_variant = 'editRequest_variant',
  forwardAccord = 'forwardAccord',
  duplicateDossier = 'duplicateDossier',
  forwardToDSC = 'forwardToDSC',
  assignToCTB_inline = 'assignToCTB_inline',
  sendOPCToSupervisor = 'sendOPCToSupervisor',
  forwardToCTB_btn = 'forwardToCTB_btn',
  opcNonValid = 'opcNonValid',
  opcValid = 'opcValid',
  modificationOPC = 'modificationOPC',
  remiseOPC = 'remiseOPC',
  physicalTransferToClient = 'physicalTransferToClient',
  receiptOPC = 'receiptOPC',
  requestMoreInfo_ctb = 'requestMoreInfo_ctb',
  transferControlWarranties = 'transferControlWarranties',
  transferNotaryRelationship = 'transferNotaryRelationship',
  notaryMinutesRequest = 'notaryMinutesRequest',
  requestDocuments = 'requestDocuments',
  rejectWarranties = 'rejectWarranties',
  validateWarranties = 'validateWarranties',
  returnDossier_btn = 'returnDossier_btn',
  validateDossier_btn = 'validateDossier_btn',
  additionalInfoCTBToSupervisor = 'additionalInfoCTBToSupervisor',
  release = 'release',
  partialRelease = 'partialRelease',
  receivePhysicalFile = 'receivePhysicalFile',
  revoirGaranties_1 = 'revoirGaranties_1',
  revoirGaranties_2 = 'revoirGaranties_2',
  transferToDrDRPP = 'transferToDrDRPP',
  respenseExpertise_exp = 'respenseExpertise_exp',
  respenseExpertise_validate = 'respenseExpertise_validate',
  takeCharge = 'takeCharge',
  assignToCTB_pool = 'assignToCTB_pool',
  agreementRisk_role = 'agreementRisk_role',
  reaffect = 'reaffect',
  authorized_validDossier = 'authorized_validDossier',
  authorized_rejectDossier = 'authorized_rejectDossier',
  authorized_revoirProposition = 'authorized_revoirProposition',
  authorized_sendDossier = 'authorized_sendDossier',
  authorized_risktransfert = 'authorized_risktransfert',
  authorized_agreementrequest = 'authorized_agreementrequest',
  authorized_agreementRisk = 'authorized_agreementRisk',
  authorized_RevoirGarantiesReserves = 'authorized_RevoirGarantiesReserves',
  onSendDossier_generic = 'onSendDossier_generic',
  openDossierRequestsModal_alt = 'openDossierRequestsModal_alt'
}

export type RuleRef =
  | { key: string; args?: any[] } // parametric rule
  | string                          // rule key name
  | { op: 'and' | 'or'; rules: RuleRef[] };

export interface ActionMeta {
  id: ActionId;
  actionKey: string;       // logical key (used by component mapping)
  labelKey?: string;
  icon?: string;
  class?: string;
  permissions?: string[];
  visibilityIf?: RuleRef;  // refer to rule keys in actions.rules.ts (eg. 'isStatus' with args)
  disabledIf?: RuleRef;
  passDossierProp?: string;
  group?: 'left' | 'right';
  notes?: string;
}

/**
 * Full ACTIONS array (all actions found in index.ts / index.html).
 * visibilityIf / disabledIf are expressed as RuleRef; evaluation done by actions.rules.ts
 */
export const ACTIONS: ActionMeta[] = [
  {
    id: ActionId.openDossierRequestsModal,
    actionKey: 'openRequests',
    labelKey: 'dossier.requests.label',
    icon: 'assets/svg/demandes.svg',
    class: 'comments-btn',
    visibilityIf: 'always',
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.editDossier,
    actionKey: 'editDossier',
    labelKey: 'button.editDossier.label',
    class: 'default-btn',
    permissions: [Permissions.ROLE_PP_UPDATE_DOSSIER],
    visibilityIf: { key: 'isStatus', args: [[
      Status.INITIATION,
      Status.ADDITIONAL_AGENCY_INFORMATION_VALIDATION,
      Status.ADDITIONAL_AGENCY_INFORMATION_DECISION,
      Status.INCA_AANR,
      Status.INCA_AVRS_RANR,
      Status.INFO_COMP_AGREEMENT_RISK,
      Status.INFO_COMP_DECISION_RS
    ]]},
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.responseMoreInfo_initiator,
    actionKey: 'responseMoreInfo',
    labelKey: 'button.sendDossier.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_RETURN_ADD_INFOS],
    visibilityIf: { op: 'or', rules: [ { key: 'isStatus', args: [[Status.ADDITIONAL_AGENCY_INFORMATION_VALIDATION]] }, { key: 'isTaskStatus', args: [[Status.INCA_EXP, Status.INCA_EXPS]] } ] },
    disabledIf: { key: 'not_hasAllMandatoryAttachments' },
    group: 'left'
  },

  {
    id: ActionId.responseMoreInfo_decision,
    actionKey: 'responseMoreInfo',
    labelKey: 'button.decision.sendDossier.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_RETURN_ADD_INFOS],
    visibilityIf: { op: 'or', rules: [
      { key: 'isStatus', args: [[
        Status.ADDITIONAL_AGENCY_INFORMATION_DECISION,
        Status.INCA_RIDN,
        Status.INFO_COMP_AGREEMENT_RISK,
        Status.INFO_COMP_DECISION_RS,
        Status.DECS_ANR_INCA_RIDN,
        Status.AVRS_INCA_RIDN,
        Status.AVRS_ANR_INCA_RIDN,
        Status.DECS_RS_INCA_RIDN,
        Status.DECS_RS_FINAL_RIND,
        Status.DECS_RS_FINAL_INCA_RIDN
      ]]},
      { key: 'isTaskStatus', args: [[Status.INCA_EXP, Status.INCA_EXPS]]}
    ]},
    disabledIf: { key: 'hasAllMandatoryAttachments' },
    group: 'left'
  },

  {
    id: ActionId.sendToDecisionAuthority,
    actionKey: 'sendToDecisionAuthority',
    labelKey: 'button.sendDossier.label',
    class: 'default-btn',
    permissions: [Permissions.ROLE_PP_TRANSFER_TO_DECISION_AUTHORITY],
    visibilityIf: { key: 'isStatus', args: [[Status.COMPLIANCE_CONTROL]] },
    disabledIf: { key: 'not_isAllAttachmentsConform' },
    group: 'left'
  },

  {
    id: ActionId.requestMoreInfo_validator,
    actionKey: 'requestMoreInfo',
    labelKey: 'button.requestMoreInfo.label',
    class: 'default-btn',
    permissions: [Permissions.ROLE_PP_REQUEST_ADD_INFOS_VALIDATOR],
    visibilityIf: { key: 'isStatus', args: [[Status.COMPLIANCE_CONTROL]] },
    disabledIf: { key: 'not_isAllAttachmentsControlled' },
    group: 'left'
  },

  {
    id: ActionId.requestMoreInfo_combined,
    actionKey: 'requestMoreInfo',
    labelKey: 'button.requestMoreInfo.label',
    class: 'default-btn add-btn',
    permissions: [
      Permissions.ROLE_PP_REQUEST_ADD_INFOS_DECISION,
      Permissions.ROLE_PP_REQUEST_ADD_INFOS_RISK,
      Permissions.ROLE_PP_REQUEST_ADD_INFOS_CTB_EXPASS,
      Permissions.ANALYSIS_RETAIL_MORE_INFOS,
      Permissions.ROLE_PP_REQUEST_ADD_INFOS_CTB
    ],
    visibilityIf: { op: 'or', rules: [
      { key: 'isStatus', args: [[
        Status.DECISION, Status.DECS_RIDN, Status.DECISION_RS, Status.AGREEMENT_RISK,
        Status.AANR, Status.DECS_ANR_RIDN, Status.INFO_COMP_RETOUR_ANALIST_RETAIL, Status.AGREEMENT_RISK_ANALIST_RETAIL
      ]]},
      { key: 'isTaskStatus', args: [[Status.REXP, Status.REXPR]] }
    ]},
    disabledIf: { op: 'or', rules: [
      { op: 'and', rules: [ { key: 'isTaskStatus', args: [[Status.REXP, Status.REXPR]] }, { key: 'hasAllMandatoryAttachments' } ] },
      { key: 'not_isAllAttachmentsControlled' }
    ]},
    group: 'left'
  },

  {
    id: ActionId.sendBackToDecision,
    actionKey: 'sendBackToDecision',
    labelKey: 'button.returnToDecision.label',
    class: 'default-btn',
    permissions: [Permissions.ROLE_PP_RETURN_TO_DECISION],
    visibilityIf: { key: 'isStatus', args: [[
      Status.DOSSIER_APPROUVED, Status.INCA_GEN, Status.DOSSIER_AVIS_RISK_APPROUVED,
      Status.DOSSIER_APPROUVED_RISK, Status.OPC_REMISE_AU_CLIENT
    ]]},
    disabledIf: { op: 'or', rules: [
      { key: 'isDecisionRetryConsumed' },
      { op: 'and', rules: [ { key: 'hasNotAllMandatoryAttachments' }, { key: 'isStatus', args: [[Status.OPC_REMISE_AU_CLIENT]] } ] }
    ]},
    group: 'left'
  },

  {
    id: ActionId.editRequest_variant,
    actionKey: 'sendBackToDecision',
    labelKey: 'button.editRequest.label',
    class: 'default-btn',
    permissions: [Permissions.ROLE_PP_RETURN_TO_DECISION],
    visibilityIf: { key: 'isStatus', args: [[
      Status.INCA_RIDN,
      Status.DECS_ANR_INCA_RIDN,
      Status.AVRS_INCA_RIDN,
      Status.AVRS_ANR_INCA_RIDN,
      Status.DECS_RS_INCA_RIDN,
      Status.DECS_RS_FINAL_RIND,
      Status.DECS_RS_FINAL_INCA_RIDN
    ]]},
    disabledIf: { op: 'or', rules: [
      { key: 'isDecisionRetryConsumed' },
      { op: 'and', rules: [ { key: 'hasNotAllMandatoryAttachments' }, { key: 'isStatus', args: [[Status.OPC_REMISE_AU_CLIENT]] } ] }
    ]},
    group: 'left'
  },

  {
    id: ActionId.forwardAccord,
    actionKey: 'forwardAccord',
    labelKey: 'button.forwardEditer.label',
    class: 'default-btn',
    permissions: [Permissions.ROLE_PP_RETURN_TO_DECISION],
    visibilityIf: { op: 'and', rules: [ { key: 'isStatus', args: [[Status.DOSSIER_APPROUVED]] }, { key: 'dossierHasAccordPrincipe' } ] },
    disabledIf: { op: 'or', rules: [ { key: 'isDecisionRetryConsumed' }, { key: 'hasNotAllMandatoryAttachments' } ] },
    group: 'left'
  },

  {
    id: ActionId.duplicateDossier,
    actionKey: 'duplicateDossier',
    labelKey: 'DUPLIQUER',
    class: 'default-btn',
    permissions: [Permissions.ROLE_PP_RETURN_TO_DECISION],
    visibilityIf: { op: 'and', rules: [ { key: 'isStatus', args: [[Status.DOSSIER_APPROUVED]] }, { key: 'isProspect' } ] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.forwardToDSC,
    actionKey: 'forwardToDSC',
    labelKey: 'button.forwardToDSC.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_FORWARD_TO_DSC],
    visibilityIf: { op: 'and', rules: [ { key: 'isStatus', args: [[Status.DOSSIER_APPROUVED]] }, { key: 'dossierAccordIsDefinitif' } ] },
    disabledIf: { key: 'not_hasAllMandatoryAttachments' },
    group: 'left'
  },

  {
    id: ActionId.assignToCTB_inline,
    actionKey: 'assignToCTB',
    labelKey: 'button.assignToCTB.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_REASSIGN_DOSSIER],
    visibilityIf: { op: 'and', rules: [ { key: 'isStatus', args: [[Status.A_TRAITER_DSC]] }, { key: 'codeStatusEqualsTaskStatus' } ] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.sendOPCToSupervisor,
    actionKey: 'sendOPCToSupervisor',
    labelKey: 'button.transfer.to.supervisor.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_REQUEST_OPC_VALIDATION],
    visibilityIf: { key: 'isStatus', args: [[Status.INCD_GEN, Status.A_TRAITER_DSC_CTB, Status.OPCAM_GEN]] },
    disabledIf: { op: 'or', rules: [ { key: 'not_isAllAttachmentsConform' }, { key: 'hasNotAllMandatoryAttachments' } ] },
    group: 'left'
  },

  {
    id: ActionId.forwardToCTB_btn,
    actionKey: 'forwardToCTB',
    labelKey: 'button.forwardToCtb.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_RETURN_ADD_INFOS],
    visibilityIf: { key: 'isStatus', args: [[Status.INCA_GEN]] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.opcNonValid,
    actionKey: 'opcNonValid',
    labelKey: 'button.opcNonValid.label',
    class: 'default-btn',
    permissions: [Permissions.ROLE_PP_RETURN_OPC_COMPLETION],
    visibilityIf: { op: 'and', rules: [ { key: 'isStatus', args: [[Status.OPCA]] }, { key: 'codeStatusEqualsTaskStatus' } ] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.opcValid,
    actionKey: 'opcValid',
    labelKey: 'button.opcValid.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_TRANSFER_OPC_INITIATOR],
    visibilityIf: { op: 'and', rules: [ { key: 'isStatus', args: [[Status.OPCA]] }, { key: 'codeStatusEqualsTaskStatus' } ] },
    disabledIf: { key: 'not_hasAllMandatoryAttachments' },
    group: 'left'
  },

  {
    id: ActionId.modificationOPC,
    actionKey: 'modificationOPC',
    labelKey: 'button.modification.OPC.label',
    class: 'default-btn',
    permissions: [Permissions.ROLE_PP_RETURN_OPC_COMPLETION],
    visibilityIf: { key: 'isStatus', args: [[Status.OPC_VALIDATED]] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.remiseOPC,
    actionKey: 'remiseOPC',
    labelKey: 'button.remise.OPC.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_DELIVER_OPC],
    visibilityIf: { key: 'isStatus', args: [[Status.OPC_VALIDATED]] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.physicalTransferToClient,
    actionKey: 'physicalTransferToClient',
    labelKey: 'button.dossier.transferToClient',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_CONTROL_PHYSICAL_DOSSIER],
    visibilityIf: { key: 'isStatus', args: [[Status.OPC_SIGNE, Status.OPC_WAITING_EXPERTISE]] },
    disabledIf: { op: 'or', rules: [ { key: 'isStatus', args: [[Status.OPC_WAITING_EXPERTISE]] }, { key: 'hasNotAllMandatoryAttachments' } ] },
    group: 'left'
  },

  {
    id: ActionId.receiptOPC,
    actionKey: 'receiptOPC',
    labelKey: 'receipt.OPC.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_RECEIVE_SIGNED_OPC],
    visibilityIf: { key: 'isStatus', args: [[Status.OPC_REMISE_AU_CLIENT]] },
    disabledIf: { key: 'hasNotAllMandatoryAttachments' },
    group: 'left'
  },

  {
    id: ActionId.requestMoreInfo_ctb,
    actionKey: 'requestMoreInfo',
    labelKey: 'button.requestMoreInfo.label',
    class: 'default-btn demande-btn',
    permissions: [Permissions.ROLE_PP_REQUEST_ADD_INFOS_CTB],
    visibilityIf: { key: 'isStatus', args: [[Status.A_TRAITER_DSC_MIS, Status.CONTROLE_MIN_ENG, Status.INCD_MIS]] },
    disabledIf: { op: 'or', rules: [ { key: 'not_isAllAttachmentsControlled' }, { key: 'hasMandatoryAttachmentsAndCodeStatusA_TRAITER_DSC' } ] },
    group: 'left'
  },

  {
    id: ActionId.transferControlWarranties,
    actionKey: 'transferControlWarranties',
    labelKey: 'button.transfer.control.warranties.label',
    class: 'default-btn',
    permissions: [Permissions.ROLE_PP_TRANSFER_CONTROL_WARRANTIES],
    visibilityIf: { key: 'isStatus', args: [[Status.A_TRAITER_DSC_MIS, Status.CONTROLE_MIN_ENG, Status.INCD_MIS]] },
    disabledIf: { op: 'or', rules: [ { key: 'not_isAllAttachmentsConform' }, { key: 'hasNotAllMandatoryAttachments' } ] },
    group: 'left'
  },

  {
    id: ActionId.transferNotaryRelationship,
    actionKey: 'transferNotaryRelationship',
    labelKey: 'button.transfer.notary.relationship.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_TRANSFER_NOTARY_RELATIONSHIP],
    visibilityIf: { key: 'isStatus', args: [[Status.A_TRAITER_DSC_MIS, Status.CONTROLE_MIN_ENG, Status.INCD_MIS]] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.notaryMinutesRequest,
    actionKey: 'notaryMinutes',
    labelKey: 'button.forwardToCtb.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_TRANSFER_MINUTE_CHECK],
    visibilityIf: { key: 'isStatus', args: [[Status.ATTENTE_RETOUR_NOTAIRE]] },
    disabledIf: { key: 'hasNotAllMandatoryAttachments' },
    group: 'left'
  },

  {
    id: ActionId.requestDocuments,
    actionKey: 'requestDocuments',
    labelKey: 'button.request.documents.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_REQUEST_MINUTE],
    visibilityIf: { key: 'isStatus', args: [[Status.TRAITER_RELATION_NOTAIRE]] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.rejectWarranties,
    actionKey: 'rejectWarranties',
    labelKey: 'button.requestMoreInfoForWarranties.label',
    class: 'default-btn',
    permissions: [Permissions.ROLE_PP_REQUEST_DOSSIER_COMPLETION],
    visibilityIf: { op: 'and', rules: [ { key: 'isStatus', args: [[Status.CONTROLE_GARANTIE]] }, { key: 'not_poolCandidateAssignedToMe' } ] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.validateWarranties,
    actionKey: 'validateWarranties',
    labelKey: 'button.validateWarranties.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_VALIDATE_BEFORE_RELEASE],
    visibilityIf: { key: 'isStatus', args: [[Status.CONTROLE_GARANTIE]] },
    disabledIf: { key: 'hasNotAllMandatoryAttachments' },
    group: 'left'
  },

  {
    id: ActionId.returnDossier_btn,
    actionKey: 'returnDossier',
    labelKey: 'button.returnDossier.label',
    class: 'default-btn',
    permissions: [Permissions.ROLE_PP_REQUEST_DOSSIER_COMPLETION],
    visibilityIf: { key: 'isStatus', args: [[Status.TO_VALIDATE]] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.validateDossier_btn,
    actionKey: 'validateDossier',
    labelKey: 'button.validateDossier.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_TRANSFER_FOR_RELEASE],
    visibilityIf: { key: 'isStatus', args: [[Status.TO_VALIDATE]] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.additionalInfoCTBToSupervisor,
    actionKey: 'additionalInfoCTBToSupervisor',
    labelKey: 'button.sendDossier.label',
    class: 'default-btn',
    permissions: [Permissions.ROLE_PP_RETURN_ADD_INFOS],
    visibilityIf: { key: 'isStatus', args: [[Status.TO_VALIDATE]] },
    disabledIf: { key: 'not_isAllAttachmentsConform' },
    group: 'left'
  },

  {
    id: ActionId.release,
    actionKey: 'release',
    labelKey: 'button.release.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_RELEASE],
    visibilityIf: { key: 'isStatus', args: [[Status.ADEB, Status.DEBP]] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.partialRelease,
    actionKey: 'partialRelease',
    labelKey: 'button.partial.release.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_RELEASE],
    visibilityIf: { key: 'isStatus', args: [[Status.DEM_DEBP]] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.receivePhysicalFile,
    actionKey: 'receivePhysicalFile',
    labelKey: 'button.receivePhysicalFile.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_RECEIVE_PHYSICAL_FILE],
    visibilityIf: { key: 'isStatus', args: [[Status.ATDP]] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.revoirGaranties_1,
    actionKey: 'revoirGaranties',
    labelKey: 'button.RevoirGarantiesReserves.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_UPDATE_DOSSIER],
    visibilityIf: { key: 'isStatus', args: [[Status.DECISION_RS, Status.DECS_RIDN, Status.AVRS_RIDN, Status.AVRS_ANR_RIDN]] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.revoirGaranties_2,
    actionKey: 'revoirGaranties',
    labelKey: 'button.RevoirGarantiesReserves.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_UPDATE_DOSSIER],
    visibilityIf: { key: 'isStatus', args: [[Status.AANR, Status.DECS_ANR_RIDN, Status.AVRS_ANR_INCANR_RIDN, Status.INFO_COMP_RETOUR_ANALIST_RETAIL]] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.transferToDrDRPP,
    actionKey: 'transferToDrDRPP',
    labelKey: 'button.sendDossier.label',
    class: 'default-btn',
    permissions: [Permissions.ROLE_PP_TRANSFER_TO_FEEDEBACK_DRPP_DR],
    visibilityIf: { key: 'isStatus', args: [[Status.AANR, Status.DECS_ANR_RIDN, Status.AVRS_ANR_INCANR_RIDN, Status.INFO_COMP_RETOUR_ANALIST_RETAIL]] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.respenseExpertise_exp,
    actionKey: 'respenseExpertise',
    labelKey: 'button.sendDossier.label',
    class: 'default-btn',
    permissions: [Permissions.ROLE_PP_TRANSFER_TO_FEEDEBACK_DRPP_DR],
    visibilityIf: { key: 'isTaskStatus', args: [[Status.REXP, Status.EXPS]] },
    disabledIf: { key: 'hasNotAllMandatoryAttachments' },
    passDossierProp: 'taskStatus',
    group: 'left'
  },

  {
    id: ActionId.respenseExpertise_validate,
    actionKey: 'respenseExpertise',
    labelKey: 'button.validateDossier.label',
    class: 'default-btn',
    permissions: [Permissions.ROLE_PP_TRANSFER_TO_FEEDEBACK_DRPP_DR],
    visibilityIf: { key: 'isTaskStatus', args: [[Status.REXPR]] },
    disabledIf: { key: 'hasNotAllMandatoryAttachments' },
    passDossierProp: 'taskStatus',
    group: 'left'
  },

  {
    id: ActionId.takeCharge,
    actionKey: 'takeCharge',
    labelKey: 'button.takeCharge.label',
    class: 'action-btn',
    permissions: [],
    visibilityIf: { key: 'isPoolCandidateAndNotAssignedToMe' },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.assignToCTB_pool,
    actionKey: 'assignToCTB',
    labelKey: 'button.assignToCTB.label',
    class: 'action-btn',
    permissions: [],
    visibilityIf: { op: 'and', rules: [ { key: 'not_assignee' }, { key: 'hasRole', args: [[Role.ASSING_POOL_SUPERVISORS]] }, { key: 'isStatus', args: [[Status.OPCA]] } ] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.agreementRisk_role,
    actionKey: 'agreementRisk',
    labelKey: 'button.agreementRisk.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_TRANSFER_TO_RESP_RISK],
    visibilityIf: { op: 'and', rules: [ { key: 'isStatus', args: [[Status.DECISION_RS]] }, { key: 'dossierNotAssignedAndNotPoolCandidate' }, { key: 'currentUserIs', args: [['ARR','ROR','RORE','DRR']] } ] },
    disabledIf: 'never',
    group: 'left'
  },

  {
    id: ActionId.reaffect,
    actionKey: 'reaffect',
    labelKey: 'button.reaffect.label',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_REASSIGN_DOSSIER],
    visibilityIf: { key: 'showReassignMenuTrigger' },
    disabledIf: 'never',
    group: 'left'
  },

  // Right / dropdown actions (authorizedActions menu)
  {
    id: ActionId.authorized_validDossier,
    actionKey: 'grantLoan',
    labelKey: 'button.validDossier.label',
    icon: 'assets/svg/valid.svg',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_ACCORD_DOSSIER],
    visibilityIf: { key: 'isStatus', args: [[
      Status.DECS_RIDN, Status.AVRS_RIDN, Status.AVRS_ANR_RIDN, Status.DECISION,
      Status.AGREEMENT_RISK, Status.DECISION_RS, Status.AGREEMENT_RISK_ANALIST_RETAIL,
      Status.DECS_RS_RIND, Status.DECS_RS_FINAL_RIND
    ]]},
    disabledIf: 'never',
    group: 'right'
  },

  {
    id: ActionId.authorized_rejectDossier,
    actionKey: 'rejectDossier',
    labelKey: 'button.rejectDossier.label',
    icon: 'assets/svg/reject.svg',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_REJECT_DOSSIER],
    visibilityIf: { key: 'isStatus', args: [[Status.DECISION, Status.DECISION_RS, Status.AGREEMENT_RISK, Status.AGREEMENT_RISK_ANALIST_RETAIL]] },
    disabledIf: 'never',
    group: 'right'
  },

  {
    id: ActionId.authorized_revoirProposition,
    actionKey: 'revoirProposition',
    labelKey: 'button.revoirProposition.label',
    icon: 'assets/svg/revoirProposition.svg',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_REVIEW_REQUEST],
    visibilityIf: { op: 'and', rules: [ { key: 'isStatus', args: [[Status.DECS_RIDN, Status.AVRS_RIDN, Status.AVRS_ANR_RIDN, Status.DECS_RS_RIND, Status.DECS_RS_FINAL_RIND]] }, { key: 'haRequestInProgress' } ] },
    disabledIf: 'never',
    group: 'right'
  },

  {
    id: ActionId.authorized_sendDossier,
    actionKey: 'sendDossier',
    labelKey: 'button.sendDossier.label',
    icon: 'assets/svg/sendDossier.svg',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_ACCORD_DOSSIER],
    visibilityIf: { key: 'isStatus', args: [[
      Status.NOTIFICATION_GENERATED, Status.NOTIFICATION_GENERATED_RISK, Status.NOTIFICATION_GENERATED_RIDN,
      Status.NOTIF_AVRS_RIDN, Status.NOTIF_AVRS, 'NOTIF_AVRS_ANR'
    ]]},
    disabledIf: 'never',
    group: 'right'
  },

  {
    id: ActionId.authorized_risktransfert,
    actionKey: 'riskTransfert',
    labelKey: 'button.risktransfert.label',
    icon: 'assets/svg/risktransfert.svg',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_TRANSFER_TO_RISK],
    visibilityIf: { op: 'and', rules: [ { key: 'isStatus', args: [[Status.DECISION, Status.AGREEMENT_RISK, Status.AGREEMENT_RISK_ANALIST_RETAIL, Status.AVRS_RIDN, Status.DECS_RIDN, Status.AVRS_ANR_RIDN]] }, { key: 'currentUserIsNot', args: [['DA','DCL']] } ] },
    disabledIf: 'never',
    group: 'right'
  },

  {
    id: ActionId.authorized_agreementrequest,
    actionKey: 'agreementRequest',
    labelKey: 'button.agreementrequest.label',
    icon: 'assets/svg/agreementrequest.svg',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_REQUEST_RISK_AGREEMENT],
    visibilityIf: { op: 'or', rules: [ { key: 'isStatus', args: [[Status.DECISION, Status.AGREEMENT_RISK_ANALIST_RETAIL, Status.DECS_RIDN, Status.AVRS_RIDN, Status.AVRS_ANR_RIDN]] }, { op: 'and', rules: [ { key: 'isStatus', args: [[Status.AGREEMENT_RISK]] }, { key: 'currentUserIs', args: [['DRPP']] } ] } ] },
    disabledIf: 'never',
    group: 'right'
  },

  {
    id: ActionId.authorized_agreementRisk,
    actionKey: 'agreementRisk_dropdown',
    labelKey: 'button.agreementRisk.label',
    icon: 'assets/svg/agreementrequest.svg',
    class: 'action-btn',
    permissions: [Permissions.ROLE_PP_TRANSFER_TO_RESP_RISK],
    visibilityIf: { key: 'isStatus', args: [[Status.DECISION_RS]] },
    disabledIf: 'never',
    group: 'right'
  },

  {
    id: ActionId.authorized_RevoirGarantiesReserves,
    actionKey: 'revoirGaranties_dropdown',
    labelKey: '
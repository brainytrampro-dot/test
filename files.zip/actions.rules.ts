// actions.rules.ts
// Factory that exposes rule functions used by visibilityIf / disabledIf in ACTIONS.
// Keep these pure and small. Provide ctx object from component to evaluate rules synchronously.

import type { DossierData } from '@core/models';
import { RequestStatus } from '@loan-dossier/enumeration';
import { AccordType } from '@core/models/Accord';
import { Status } from '@loan-dossier/constants';

export type RulesCtx = {
  userService?: any;
  permManager?: any;
  dossierDataService?: any;
  dossierRequestInProgress?: any;
  isAllAttachmentControlled?: boolean;
  isAllAttachmentControlledOK?: boolean;
  hasMandatoryAttachments?: boolean | undefined;
  currentDossierUser?: any;
  currentUserCodeProfession?: string;
  isProspect?: boolean;
  showReassignMenuTrigger?: (d: DossierData) => boolean;
};

export function makeRules(ctx: RulesCtx) {
  return {
    always: (_?: DossierData) => true,
    never: (_?: DossierData) => false,

    isStatus: (statuses: string[]) => (d?: DossierData) => !!d && statuses.includes(d.codeStatus as string),
    isTaskStatus: (tasks: string[]) => (d?: DossierData) => !!d && tasks.includes(d.taskStatus as string),

    isAssignedToMe: (_?: DossierData) => !!ctx?.currentDossierUser && !!ctx.currentDossierUser.user && ctx.currentDossierUser.user.matricule === ctx?.userService?.currentUserMatricule,

    isAllAttachmentsControlled: () => !!ctx?.isAllAttachmentControlled,
    isAllAttachmentsConform: () => !!ctx?.isAllAttachmentControlledOK,

    hasAllMandatoryAttachments: () => ctx?.hasMandatoryAttachments === true || ctx?.dossierDataService?.hasAllMandatoryAttachments === true,
    not_hasAllMandatoryAttachments: () => !(ctx?.hasMandatoryAttachments === true || ctx?.dossierDataService?.hasAllMandatoryAttachments === true),
    hasNotAllMandatoryAttachments: () => ctx?.hasMandatoryAttachments === false || ctx?.dossierDataService?.hasAllMandatoryAttachments === false,

    haRequestInProgress: () => !!ctx?.dossierRequestInProgress && ctx.dossierRequestInProgress.requestStatus === RequestStatus.IN_PROGRESS,

    hasRole: (roles: string[]) => () => ctx?.userService?.hasRole ? ctx.userService.hasRole(roles) : false,
    currentUserIs: (professions: string[]) => () => professions.includes(ctx?.userService?.currentUserCodeProfession),
    currentUserIsNot: (professions: string[]) => () => !professions.includes(ctx?.userService?.currentUserCodeProfession),

    isDecisionRetryConsumed: (d?: DossierData) => !!d && !d.returnDecisionInstance,

    codeStatusEqualsTaskStatus: (d?: DossierData) => !!d && d.codeStatus === d.taskStatus,
    dossierHasAccordPrincipe: (d?: DossierData) => !!d && d.accord === AccordType.PRINCIPE,
    dossierAccordIsDefinitif: (d?: DossierData) => !!d && d.accord === AccordType.DEFINITIF,
    isProspect: () => !!ctx?.isProspect,

    isPoolCandidateAndNotAssignedToMe: (d?: DossierData) => !!d && d.poolCandidate && !d.assignedToMe,
    not_assignee: (d?: DossierData) => !!d && !d.assignee,
    dossierNotAssignedAndNotPoolCandidate: (d?: DossierData) => !!d && !d.assignedToMe && !d.poolCandidate,

    hasMandatoryAttachmentsAndCodeStatusA_TRAITER_DSC: (d?: DossierData) => {
      return !!d && (ctx?.hasMandatoryAttachments === true || ctx?.dossierDataService?.hasAllMandatoryAttachments === true) && d.codeStatus === Status.A_TRAITER_DSC_CTB;
    },

    not_isAllAttachmentsControlled: () => !ctx?.isAllAttachmentControlled,
    not_isAllAttachmentsConform: () => !ctx?.isAllAttachmentControlledOK,

    showReassignMenuTrigger: (d?: DossierData) => typeof ctx?.showReassignMenuTrigger === 'function' ? ctx.showReassignMenuTrigger(d) : false,

    isPermitted: (perms: string[]) => () => ctx?.permManager?.isGranted ? ctx.permManager.isGranted(perms) : false
  };
}

/**
 * evaluateRuleDescriptor helper (simple evaluator for RuleRef types used in ACTIONS).
 * Accepts rulesObj (from makeRules(ctx)), descriptor (string | {key,args} | {op,...}) and dossier.
 */
export function evaluateRuleDescriptor(rulesObj: any, descriptor: any, dossier?: any): boolean {
  if (!descriptor) return true;
  const evalOne = (desc: any): boolean => {
    if (typeof desc === 'string') {
      const r = rulesObj[desc];
      if (typeof r === 'function') {
        const res = r(dossier);
        return typeof res === 'function' ? res(dossier) : !!res;
      }
      return !!r;
    }
    if (desc.key) {
      const fn = rulesObj[desc.key];
      if (typeof fn !== 'function') {
        console.warn('Missing rule', desc.key);
        return true;
      }
      const res = Array.isArray(desc.args) ? fn(...desc.args) : fn(desc.args);
      return typeof res === 'function' ? res(dossier) : !!res;
    }
    if (desc.op) {
      if (desc.op === 'and') return desc.rules.every((r: any) => evaluateRuleDescriptor(rulesObj, r, dossier));
      return desc.rules.some((r: any) => evaluateRuleDescriptor(rulesObj, r, dossier));
    }
    return true;
  };
  try { return evalOne(descriptor); } catch (e) { console.warn('rule eval error', e); return true; }
}